<?php

/* IJVRSearchBundle:Default:advancedSearch.html.twig */
class __TwigTemplate_e2039088a41c9b99b1adb9aaeb831531e0791a78bb8591458d350b3fe94ba7a1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::layout.html.twig", "IJVRSearchBundle:Default:advancedSearch.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a1dd2c51858dfd20723fa60ca7095425a4fb35bf178d918eb9c0819f61bb479f = $this->env->getExtension("native_profiler");
        $__internal_a1dd2c51858dfd20723fa60ca7095425a4fb35bf178d918eb9c0819f61bb479f->enter($__internal_a1dd2c51858dfd20723fa60ca7095425a4fb35bf178d918eb9c0819f61bb479f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "IJVRSearchBundle:Default:advancedSearch.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a1dd2c51858dfd20723fa60ca7095425a4fb35bf178d918eb9c0819f61bb479f->leave($__internal_a1dd2c51858dfd20723fa60ca7095425a4fb35bf178d918eb9c0819f61bb479f_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_73f84f38fd0715328c896716a929148dd9865b7af667d732f780f2d6b09368a9 = $this->env->getExtension("native_profiler");
        $__internal_73f84f38fd0715328c896716a929148dd9865b7af667d732f780f2d6b09368a9->enter($__internal_73f84f38fd0715328c896716a929148dd9865b7af667d732f780f2d6b09368a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $this->displayParentBlock("title", $context, $blocks);
        echo " - Index";
        
        $__internal_73f84f38fd0715328c896716a929148dd9865b7af667d732f780f2d6b09368a9->leave($__internal_73f84f38fd0715328c896716a929148dd9865b7af667d732f780f2d6b09368a9_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_b86eefb0370a85ddbb1066f80f4dd50e8754fa11cc49d4a6ddf63df916be7c7f = $this->env->getExtension("native_profiler");
        $__internal_b86eefb0370a85ddbb1066f80f4dd50e8754fa11cc49d4a6ddf63df916be7c7f->enter($__internal_b86eefb0370a85ddbb1066f80f4dd50e8754fa11cc49d4a6ddf63df916be7c7f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "<script>\$(document).ready(function() {
    var max_fields      = 10; //maximum input boxes allowed
    var wrapper         = \$(\".input_fields_wrap\"); //Fields wrapper
    var add_button      = \$(\".add_field_button\"); //Add button ID
    
    var x = 1; //initlal text box count
    \$(add_button).click(function(e){ //on add input button click
        e.preventDefault();
        if(x < max_fields){ //max input box allowed
            x++; //text box increment
            \$(wrapper).append(' <div><input type=\"text\" class=\"form-control\" name=\"keywords[]\"/><a href=\"#\" class=\"remove_field \">Remove</a></div>'); //add input box
        }
    });
    
    \$(wrapper).on(\"click\",\".remove_field\", function(e){ //user click on remove text
        e.preventDefault(); \$(this).parent('div').remove(); x--;
    })
});



</script>
<div class=\"container-fluid\">
\t<div class=\"row\">
\t\t<div class=\"col-md-12\">
\t\t\t<h3>
\t\t\t\tAdvanced Search
\t\t\t</h3>
\t\t\t<div class=\"row\">
\t\t\t\t<div class=\"col-md-12\">
\t\t\t\t\t
\t\t\t\t\t
\t\t\t\t\t<form class=\"form-horizontal\" id=\"advancedSearchForm\" method=\"POST\" action=\"";
        // line 38
        echo $this->env->getExtension('routing')->getPath("ijvr_advanced_search");
        echo "\">
<fieldset>

<!-- Form Name -->




<!-- Text input-->
<div class=\"form-group\">
  <label class=\"col-md-4 control-label\" for=\"textinput\">Article</label>  
  <div class=\"col-md-4\">
  <input id=\"textinput\" name=\"title\" type=\"text\"  class=\"form-control input-md\">
  
  </div>
</div>

<!-- Text input-->
<div class=\"form-group\">
  <label class=\"col-md-4 control-label\" for=\"textinput\">Issue</label>  
  <div class=\"col-md-4\">
  <input id=\"textinput\" name=\"issueTitle\" type=\"text\" class=\"form-control input-md\">

  </div>
</div>

<!-- Text input-->
<div class=\"form-group\">
  <label class=\"col-md-4 control-label\" for=\"textinput\">Keywords</label>  
  <div class=\"col-md-4 input_fields_wrap\">
 
<button class=\"add_field_button btn btn-default glyphicon glyphicon-plus btn-xs\">Add More keywords</button>
  <input id=\"textinput3\" name=\"keywords[]\" type=\"text\" class=\"form-control input-md\"><br>
  
  </div>
</div>
<div class=\"form-group\">
  <label class=\"col-md-4 control-label\" for=\"textinput\"></label>  
  <div class=\"col-md-4\">
  <button id=\"submitBtn\" name=\"textinput\" type=\"submit\" class=\"btn btn-default\">Search </button>
    
  </div>
</div>

</fieldset>
</form>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>
</div>
<script>
console.log(\$(\"#subhmitBtn\"))
\$(\"#submitBtn\").click(function(event) {
console.log(\$('#textinput3').val())
  
    
    var \$nonempty = \$('.form-control').filter(function() {
    return this.value != ''
  });

  if (\$nonempty.length == 0) {
    
     event.preventDefault();
  }
  
       
    
});


</script>
";
        
        $__internal_b86eefb0370a85ddbb1066f80f4dd50e8754fa11cc49d4a6ddf63df916be7c7f->leave($__internal_b86eefb0370a85ddbb1066f80f4dd50e8754fa11cc49d4a6ddf63df916be7c7f_prof);

    }

    public function getTemplateName()
    {
        return "IJVRSearchBundle:Default:advancedSearch.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  88 => 38,  54 => 6,  48 => 5,  35 => 3,  11 => 1,);
    }
}
/* {% extends "::layout.html.twig" %}*/
/* */
/* {% block title %}{{ parent() }} - Index{% endblock %}*/
/* */
/* {% block body %}*/
/* <script>$(document).ready(function() {*/
/*     var max_fields      = 10; //maximum input boxes allowed*/
/*     var wrapper         = $(".input_fields_wrap"); //Fields wrapper*/
/*     var add_button      = $(".add_field_button"); //Add button ID*/
/*     */
/*     var x = 1; //initlal text box count*/
/*     $(add_button).click(function(e){ //on add input button click*/
/*         e.preventDefault();*/
/*         if(x < max_fields){ //max input box allowed*/
/*             x++; //text box increment*/
/*             $(wrapper).append(' <div><input type="text" class="form-control" name="keywords[]"/><a href="#" class="remove_field ">Remove</a></div>'); //add input box*/
/*         }*/
/*     });*/
/*     */
/*     $(wrapper).on("click",".remove_field", function(e){ //user click on remove text*/
/*         e.preventDefault(); $(this).parent('div').remove(); x--;*/
/*     })*/
/* });*/
/* */
/* */
/* */
/* </script>*/
/* <div class="container-fluid">*/
/* 	<div class="row">*/
/* 		<div class="col-md-12">*/
/* 			<h3>*/
/* 				Advanced Search*/
/* 			</h3>*/
/* 			<div class="row">*/
/* 				<div class="col-md-12">*/
/* 					*/
/* 					*/
/* 					<form class="form-horizontal" id="advancedSearchForm" method="POST" action="{{path('ijvr_advanced_search')}}">*/
/* <fieldset>*/
/* */
/* <!-- Form Name -->*/
/* */
/* */
/* */
/* */
/* <!-- Text input-->*/
/* <div class="form-group">*/
/*   <label class="col-md-4 control-label" for="textinput">Article</label>  */
/*   <div class="col-md-4">*/
/*   <input id="textinput" name="title" type="text"  class="form-control input-md">*/
/*   */
/*   </div>*/
/* </div>*/
/* */
/* <!-- Text input-->*/
/* <div class="form-group">*/
/*   <label class="col-md-4 control-label" for="textinput">Issue</label>  */
/*   <div class="col-md-4">*/
/*   <input id="textinput" name="issueTitle" type="text" class="form-control input-md">*/
/* */
/*   </div>*/
/* </div>*/
/* */
/* <!-- Text input-->*/
/* <div class="form-group">*/
/*   <label class="col-md-4 control-label" for="textinput">Keywords</label>  */
/*   <div class="col-md-4 input_fields_wrap">*/
/*  */
/* <button class="add_field_button btn btn-default glyphicon glyphicon-plus btn-xs">Add More keywords</button>*/
/*   <input id="textinput3" name="keywords[]" type="text" class="form-control input-md"><br>*/
/*   */
/*   </div>*/
/* </div>*/
/* <div class="form-group">*/
/*   <label class="col-md-4 control-label" for="textinput"></label>  */
/*   <div class="col-md-4">*/
/*   <button id="submitBtn" name="textinput" type="submit" class="btn btn-default">Search </button>*/
/*     */
/*   </div>*/
/* </div>*/
/* */
/* </fieldset>*/
/* </form>*/
/* 				</div>*/
/* 			</div>*/
/* 		</div>*/
/* 	</div>*/
/* </div>*/
/* <script>*/
/* console.log($("#subhmitBtn"))*/
/* $("#submitBtn").click(function(event) {*/
/* console.log($('#textinput3').val())*/
/*   */
/*     */
/*     var $nonempty = $('.form-control').filter(function() {*/
/*     return this.value != ''*/
/*   });*/
/* */
/*   if ($nonempty.length == 0) {*/
/*     */
/*      event.preventDefault();*/
/*   }*/
/*   */
/*        */
/*     */
/* });*/
/* */
/* */
/* </script>*/
/* {% endblock %}*/
/* */
/* */
/* */
/* */
