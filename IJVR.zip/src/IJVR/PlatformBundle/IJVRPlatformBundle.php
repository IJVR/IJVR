<?php


namespace IJVR\PlatformBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class IJVRPlatformBundle extends Bundle
{
}
