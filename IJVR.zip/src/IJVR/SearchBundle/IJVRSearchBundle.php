<?php

namespace IJVR\SearchBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class IJVRSearchBundle extends Bundle
{
}
