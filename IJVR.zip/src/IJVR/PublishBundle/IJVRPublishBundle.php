<?php

namespace IJVR\PublishBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class IJVRPublishBundle extends Bundle
{
}
